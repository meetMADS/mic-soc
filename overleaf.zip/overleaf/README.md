# Overleaf documents

This folder is **drop-in ready for Overleaf**. The fastest way to use it:

1. Zip the whole `overleaf/` folder.
2. Go to Overleaf → New Project → Upload Project → upload the zip.
3. Inside Overleaf, you'll get **two compileable main files**:
   - `syllabus_main.tex` → the short syllabus (one page per week, mostly tables of topics and links).
   - `handbook_main.tex` → the long technical handbook (big-picture-first; this is what the mentee should read first each week).

Compile each with **pdfLaTeX** (Menu → Compiler → pdfLaTeX).

If you're compiling locally instead of on Overleaf:

```bash
pdflatex syllabus_main.tex && pdflatex syllabus_main.tex
pdflatex handbook_main.tex && pdflatex handbook_main.tex
```

The double-pass is needed to resolve the table of contents.

## Mentee instructions (verbatim — feel free to copy into a message)

> Every week, do the reading in this order:
>
> 1. **Open `handbook_main.pdf`** and read the relevant week's chapter
>    end-to-end. This takes 15–30 minutes and gives you the
>    *big picture* and a moderately technical sketch of every term you
>    will encounter that week.
> 2. **Open the week's slide deck** from `slides/` (see the
>    SLIDES_INDEX). Read it linearly; you will recognise every term.
> 3. **Open `syllabus_main.pdf`** for the curated link list. Pick at
>    most two links per week and read them properly.
> 4. **Do the notebooks and exercises** in `week_N/Readme.md`.
>
> The reason for this order: most students lose more time hopping
> between random search results trying to figure out what a term means
> than they do actually learning the concept. The handbook is here so
> that every external resource you read already has a slot to drop
> into.

## Files

| File | Purpose |
|---|---|
| `handbook_main.tex` | **Long Technical Handbook.** Mentee reads this first each week. |
| `syllabus_main.tex` | **Short Syllabus.** Checklist of topics + curated links per week. |
| `references.bib` | Starter BibTeX file. Not used by either main `.tex` directly (they use inline `\href`), but useful when mentees write their Week-7/8 reports. |
| `sections/`, `handbook_sections/` | Empty placeholder folders kept for future splitting (right now both main files are self-contained for simplicity). |
